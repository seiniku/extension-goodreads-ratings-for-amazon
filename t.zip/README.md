#Goodreads ratings for Chirp

**Goodreads ratings for Chirp** is a small extension that shows Goodreads ratings in Chirp pages. It also provides with a link to directly visit the Goodreads page.


##LEGAL STUFF
**Goodreads ratings for Chirp**</a> is licensed as Apache 2.0.

Based on:
https://github.com/rubenmv/extension-goodreads-ratings-for-amazon by rub3nmv@gmail.com